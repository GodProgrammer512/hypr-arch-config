# hypr-arch-config
A repository to save my Arch Linux + Hyprland (and maybe Blackarch mirror repo) rice settings. 🚀
